package group;


public interface LogWriter {
	public void write(String text);
}
