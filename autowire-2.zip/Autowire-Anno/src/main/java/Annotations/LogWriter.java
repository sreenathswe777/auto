package Annotations;


public interface LogWriter {
	public void write(String text);
}
